import importlib
import os
import sys
import tempfile
import unittest


class FlaskApiTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old_state = os.environ.get("BOT_STATE_PATH")
        env_keys = (
            "DASHBOARD_PASSWORD", "TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID",
            "OKX_DEMO_TRADING", "OKX_DEMO_API_KEY", "OKX_DEMO_API_SECRET",
            "OKX_DEMO_PASSPHRASE", "OKX_DEMO_ORDER_ARMED",
        )
        self.old_env = {key: os.environ.get(key) for key in env_keys}
        os.environ["BOT_STATE_PATH"] = os.path.join(self.tmp.name, "state.json")
        os.environ["TELEGRAM_BOT_TOKEN"] = ""
        os.environ["TELEGRAM_CHAT_ID"] = ""
        os.environ["OKX_DEMO_TRADING"] = "0"
        os.environ["OKX_DEMO_API_KEY"] = ""
        os.environ["OKX_DEMO_API_SECRET"] = ""
        os.environ["OKX_DEMO_PASSPHRASE"] = ""
        os.environ["OKX_DEMO_ORDER_ARMED"] = "0"
        self.password = "test-only-password"
        os.environ["DASHBOARD_PASSWORD"] = self.password
        sys.modules.pop("app", None)
        self.module = importlib.import_module("app")
        self.client = self.module.app.test_client()
        self.auth = ("admin", self.password)

    def tearDown(self):
        self.module.bot.stop()
        sys.modules.pop("app", None)
        if self.old_state is None:
            os.environ.pop("BOT_STATE_PATH", None)
        else:
            os.environ["BOT_STATE_PATH"] = self.old_state
        for key, value in self.old_env.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        self.tmp.cleanup()

    def test_status_is_redacted_and_reports_risk_fields(self):
        response = self.client.get("/api/status", auth=self.auth)
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        for secret_field in ("telegram_token", "telegram_chat_id", "bybit_api_key", "bybit_api_secret"):
            self.assertNotIn(secret_field, data)
        self.assertIn("daily_loss_pause", data)
        self.assertIn("confluence_candidates", data)
        self.assertIn("current_confluence_summary", data)
        self.assertEqual(data["min_confluence_score"], 3)
        self.assertEqual(data["active_strategy"], "playbook_3pillar")
        self.assertEqual(data["execution_mode"], "paper")
        self.assertTrue(data["dashboard_controls_enabled"])

    def test_live_execution_and_manual_orders_are_locked(self):
        self.assertEqual(self.client.post("/api/bybit_config", json={"execution_mode": "bybit"}, auth=self.auth).status_code, 403)
        self.assertEqual(self.client.post("/api/manual_trade", json={"side": "LONG"}, auth=self.auth).status_code, 403)

    def test_config_validates_risk_and_confluence(self):
        bad_risk = self.client.post("/api/config", json={"risk_pct": 2.5}, auth=self.auth)
        self.assertEqual(bad_risk.status_code, 400)
        bad_score = self.client.post("/api/config", json={"min_confluence_score": 4}, auth=self.auth)
        self.assertEqual(bad_score.status_code, 400)
        good = self.client.post("/api/config", json={"min_confluence_score": 3, "risk_pct": 1.0, "leverage": 10}, auth=self.auth)
        self.assertEqual(good.status_code, 200)

    def test_mutations_are_disabled_without_dashboard_password(self):
        os.environ.pop("DASHBOARD_PASSWORD", None)
        response = self.client.post("/api/reset", json={"initial_balance": 1000})
        self.assertEqual(response.status_code, 503)

    def test_page_contains_no_secret_entry_fields_and_has_setup_table(self):
        response = self.client.get("/", auth=self.auth)
        self.assertEqual(response.status_code, 200)
        body = response.get_data(as_text=True)
        self.assertIn("confluenceCandidatesBody", body)
        self.assertIn("three-pillar", body.lower())
        self.assertIn("3/3 required in every session", body)
        self.assertIn("TELEGRAM_BOT_TOKEN", body)
        self.assertNotIn("tgToken", body)
        self.assertNotIn("bybitApiSecret", body)


if __name__ == "__main__":
    unittest.main()
