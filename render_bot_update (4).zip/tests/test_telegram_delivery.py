import io
import json
import os
import tempfile
import unittest
import urllib.error
from pathlib import Path
from unittest.mock import patch
from datetime import datetime, timedelta

import bot_engine
from bot_engine import CryptoScalpBot, LAGOS_TZ


class FakeResponse:
    status = 200

    def __init__(self, payload):
        self.payload = payload

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def read(self):
        return json.dumps(self.payload).encode("utf-8")


class TelegramDeliveryTests(unittest.TestCase):
    def setUp(self):
        self.tempdir = tempfile.TemporaryDirectory()
        safe_demo_env = {
            "OKX_DEMO_TRADING": "0", "OKX_DEMO_API_KEY": "",
            "OKX_DEMO_API_SECRET": "", "OKX_DEMO_PASSPHRASE": "",
            "OKX_DEMO_ORDER_ARMED": "0",
        }
        with patch.dict(os.environ, safe_demo_env):
            self.bot = CryptoScalpBot(
                initial_balance=1000,
                state_path=str(Path(self.tempdir.name) / "state.json"),
            )
        self.bot.enable_telegram = True
        self.bot.telegram_token = "test-token-never-log-this"
        self.bot.telegram_chat_id = "123456"

    def tearDown(self):
        self.bot.stop()
        self.tempdir.cleanup()

    def test_local_env_file_loads_credentials_without_overriding_platform_environment(self):
        key = "BOT_ENGINE_TEST_TELEGRAM_TOKEN"
        previous = os.environ.get(key)
        try:
            os.environ.pop(key, None)
            with tempfile.TemporaryDirectory() as tmp:
                Path(tmp, ".env").write_text(f'{key}="local-test-value"\n', encoding="utf-8")
                with patch.object(bot_engine, "__file__", str(Path(tmp, "bot_engine.py"))):
                    bot_engine._load_local_env_file()
                self.assertEqual(os.environ.get(key), "local-test-value")
                os.environ[key] = "platform-value"
                bot_engine._load_local_env_file()
                self.assertEqual(os.environ.get(key), "platform-value")
        finally:
            if previous is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = previous

    def test_missing_credentials_explains_which_server_variables_are_needed(self):
        self.bot.telegram_token = ""
        self.bot.telegram_chat_id = ""
        ok, message = self.bot.send_telegram_alert("hello")
        self.assertFalse(ok)
        self.assertIn("TELEGRAM_BOT_TOKEN", message)
        self.assertIn("TELEGRAM_CHAT_ID", message)

    @patch("bot_engine.urllib.request.urlopen")
    def test_successful_send_confirms_telegram_api_ok(self, urlopen):
        urlopen.return_value = FakeResponse({"ok": True, "result": {"message_id": 7}})
        ok, message = self.bot.send_telegram_alert("test message")
        self.assertTrue(ok)
        self.assertIn("sent successfully", message)
        self.assertGreater(self.bot.telegram_last_success_epoch, 0)
        payload = json.loads(urlopen.call_args.args[0].data.decode("utf-8"))
        self.assertEqual(payload["chat_id"], "123456")
        self.assertEqual(payload["text"], "test message")

    @patch("bot_engine.urllib.request.urlopen")
    def test_markdown_parse_rejection_retries_as_plain_text(self, urlopen):
        url = "https://api.telegram.org/bot[redacted]/sendMessage"
        parse_error = urllib.error.HTTPError(
            url,
            400,
            "Bad Request",
            {},
            io.BytesIO(json.dumps({
                "ok": False,
                "error_code": 400,
                "description": "Bad Request: can't parse entities",
            }).encode("utf-8")),
        )
        urlopen.side_effect = [parse_error, FakeResponse({"ok": True, "result": {"message_id": 8}})]
        ok, message = self.bot.send_telegram_alert("*bold* `value` with _characters_")
        self.assertTrue(ok)
        self.assertIn("delivered as plain text", message)
        self.assertEqual(urlopen.call_count, 2)
        fallback = json.loads(urlopen.call_args_list[1].args[0].data.decode("utf-8"))
        self.assertNotIn("parse_mode", fallback)
        self.assertEqual(fallback["text"], "bold value with characters")

    @patch("bot_engine.urllib.request.urlopen")
    def test_http_rejection_is_reported_without_exposing_token(self, urlopen):
        error = urllib.error.HTTPError(
            "https://api.telegram.org/bottest-token-never-log-this/sendMessage",
            400,
            "Bad Request",
            {},
            io.BytesIO(json.dumps({
                "ok": False,
                "error_code": 400,
                "description": "Bad Request: chat not found",
            }).encode("utf-8")),
        )
        urlopen.side_effect = error
        ok, message = self.bot.send_telegram_alert("hello")
        self.assertFalse(ok)
        self.assertIn("chat not found", message)
        self.assertNotIn("test-token-never-log-this", message)
        self.assertNotIn("test-token-never-log-this", "\n".join(self.bot.logs))

    def test_start_bootstraps_numeric_chat_id_without_enabling_other_commands(self):
        self.bot.telegram_chat_id = ""
        update = {
            "update_id": 1,
            "message": {"text": "/start@btc_strategy_bot", "chat": {"id": 987654}},
        }
        responses = [
            FakeResponse({"ok": True, "result": [update]}),
            FakeResponse({"ok": True, "result": {"message_id": 9}}),
        ]
        self.bot.is_running = True

        def stop_after_poll(_seconds):
            self.bot.is_running = False

        with patch("bot_engine.urllib.request.urlopen", side_effect=responses) as urlopen, \
             patch("bot_engine.time.sleep", side_effect=stop_after_poll), \
             patch.object(self.bot, "handle_telegram_command") as handle_command:
            self.bot.telegram_polling_loop()
        self.assertEqual(urlopen.call_count, 2)
        sent = json.loads(urlopen.call_args_list[1].args[0].data.decode("utf-8"))
        self.assertEqual(sent["chat_id"], 987654)
        self.assertIn("987654", sent["text"])
        self.assertIn("\n", sent["text"])
        self.assertNotIn(r"\n", sent["text"])
        self.assertIn("TELEGRAM_CHAT_ID", sent["text"])
        handle_command.assert_not_called()
        self.assertIn("setup reply sent", self.bot.telegram_polling_status)

    def test_polling_409_is_exposed_as_webhook_conflict(self):
        error = urllib.error.HTTPError(
            "https://api.telegram.org/bot[redacted]/getUpdates",
            409,
            "Conflict",
            {},
            io.BytesIO(json.dumps({
                "ok": False,
                "error_code": 409,
                "description": "Conflict: can't use getUpdates method while webhook is active",
            }).encode("utf-8")),
        )
        self.bot.is_running = True

        def stop_after_first_poll(_seconds):
            self.bot.is_running = False

        with patch("bot_engine.urllib.request.urlopen", side_effect=error), \
             patch("bot_engine.time.sleep", side_effect=stop_after_first_poll):
            self.bot.telegram_polling_loop()
        self.assertIn("webhook is active", self.bot.telegram_polling_status)
        self.assertTrue(any("Telegram polling failed" in line for line in self.bot.logs))

    def test_quick_restart_reuses_live_poller_instead_of_creating_a_duplicate(self):
        class AlreadyAlive:
            @staticmethod
            def is_alive():
                return True

        self.bot.thread = AlreadyAlive()
        self.bot.tg_thread = AlreadyAlive()
        with patch("bot_engine.threading.Thread") as thread_factory:
            self.bot.start()
            thread_factory.assert_not_called()
        self.assertTrue(self.bot.is_running)
        self.bot.stop()

    def test_group_command_suffix_is_accepted(self):
        sent = []
        self.bot.send_telegram_alert = lambda text, chat_id=None: sent.append((text, chat_id)) or (True, "ok")
        self.bot.handle_telegram_command("/help@btc_strategy_bot", 123456)
        self.assertEqual(len(sent), 1)
        self.assertEqual(sent[0][1], 123456)
        self.assertIn("3/3", sent[0][0])

    def test_daily_noon_summary_uses_lagos_time_sends_once_and_says_no_entry_without_setup(self):
        noon = datetime(2026, 10, 1, 12, 0, tzinfo=LAGOS_TZ)
        self.bot.last_ticker_update_epoch = noon.timestamp()
        self.bot.last_indicator_update_epoch = noon.timestamp()
        self.bot.ticker_data["last"] = 12345.0
        with patch.object(self.bot, "send_telegram_alert", return_value=(True, "sent")) as send:
            self.assertFalse(self.bot.maybe_send_daily_noon_summary(noon - timedelta(minutes=1)))
            self.assertTrue(self.bot.maybe_send_daily_noon_summary(noon))
            self.assertFalse(self.bot.maybe_send_daily_noon_summary(noon + timedelta(minutes=1)))
        send.assert_called_once()
        message = send.call_args.args[0]
        self.assertIn("DAILY BTC MARKET CHECK", message)
        self.assertIn("12:00 WAT", message)
        self.assertIn("Last price: `$12345.00`", message)
        self.assertIn("NO ENTRY", message)
        state = json.loads(Path(self.bot.state_path).read_text(encoding="utf-8"))
        self.assertEqual(state["last_noon_summary_date"], "2026-10-01")

    def test_daily_noon_summary_can_be_disabled(self):
        self.bot.telegram_daily_noon_enabled = False
        noon = datetime(2026, 10, 1, 12, 0, tzinfo=LAGOS_TZ)
        with patch.object(self.bot, "send_telegram_alert") as send:
            self.assertFalse(self.bot.maybe_send_daily_noon_summary(noon))
        send.assert_not_called()

    def test_telegram_test_command_sends_delivery_check_without_order(self):
        with patch.object(self.bot, "send_telegram_alert", return_value=(True, "sent")) as send:
            self.bot.handle_telegram_command("/test@btc_strategy_bot", 123456)
        send.assert_called_once()
        text, chat_id = send.call_args.args
        self.assertEqual(chat_id, 123456)
        self.assertIn("TELEGRAM DELIVERY TEST", text)
        self.assertIn("3/3 pillars", text)
        self.assertIn("NO ORDER", text)

    def test_signal_alert_uses_three_pillar_session_threshold_and_is_not_order_confirmation(self):
        captured = []
        class FakeThread:
            def __init__(self, target=None, args=(), kwargs=None, daemon=None):
                captured.append(args[0])
            def start(self):
                pass

        self.bot.telegram_token = "test-token"
        self.bot.telegram_chat_id = "123456"
        with patch("bot_engine.threading.Thread", FakeThread):
            self.bot.dispatch_signal_notifications({
                "symbol": "BTC-USDT-SWAP", "side": "LONG", "confluence_score": 3,
                "confirmations": ["Pillar 1 trigger", "Pillar 2 VWAP", "Pillar 3 RSI"],
                "entry": 100.0, "sl": 99.0, "tp1": 101.0, "tp2": 102.0,
                "session_status": "Regular session (3/3 required)", "rrr": 2.0,
            })
        self.assertEqual(len(captured), 1)
        self.assertIn("3/3 THREE-PILLAR SETUP", captured[0])
        self.assertIn("Regular session (3/3 required)", captured[0])
        self.assertIn("not an order confirmation", captured[0])
        self.assertIn("take 50% off", captured[0])
        self.assertIn("TP2", captured[0])
        self.assertIn("move the remaining stop to fee-adjusted breakeven", captured[0])
        self.assertNotIn("4/4", captured[0])

    def test_status_explains_missing_telegram_configuration(self):
        self.bot.telegram_token = ""
        self.bot.telegram_chat_id = ""
        status = self.bot.get_status()
        self.assertIn("TELEGRAM_BOT_TOKEN", status["telegram_status"])
        self.assertFalse(status["telegram_configured"])


if __name__ == "__main__":
    unittest.main()
