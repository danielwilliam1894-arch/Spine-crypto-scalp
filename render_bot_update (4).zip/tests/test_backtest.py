import unittest

from backtest import (
    DEFAULT_RESEARCH_PARAMS,
    apply_market_fill_price,
    confluence_components,
    funding_at,
    hourly_trend_at,
    wilson_interval,
)
from bot_engine import CryptoScalpBot


class BacktestHelperTests(unittest.TestCase):
    def test_active_three_pillar_components_match_the_legacy_replay(self):
        # The active scanner and the legacy replay now share the original component rules;
        # the replay's old multi-pair results are still not proof of BTC strategy performance.
        bot = CryptoScalpBot(initial_balance=1000.0, state_path="/tmp/backtest-helper-test-no-state.json")
        ind = {
            "current_close": 98.5, "current_low": 97.0, "current_high": 101.0,
            "recent_low": 98.0, "recent_high": 102.0,
            "vwap": 100.0, "vwap_lower": 99.0, "vwap_upper": 101.0,
            "ema8": 101.0, "ema20": 100.0, "ema50": 99.0, "rsi": 35.0,
        }
        live = bot._confluence_components(ind)
        legacy_replay = confluence_components(ind, dict(DEFAULT_RESEARCH_PARAMS))
        self.assertEqual({"LONG": 3, "SHORT": 0}, {k: len(v) for k, v in live.items()})
        self.assertEqual({"LONG": 3, "SHORT": 0}, {k: len(v) for k, v in legacy_replay.items()})

    def test_adverse_slippage_direction_for_market_orders(self):
        slip = 5 / 10000
        self.assertAlmostEqual(apply_market_fill_price(100.0, "LONG", "entry", slip), 100.05)
        self.assertAlmostEqual(apply_market_fill_price(100.0, "LONG", "exit", slip), 99.95)
        self.assertAlmostEqual(apply_market_fill_price(100.0, "SHORT", "entry", slip), 99.95)
        self.assertAlmostEqual(apply_market_fill_price(100.0, "SHORT", "exit", slip), 100.05)

    def test_funding_gate_does_not_look_ahead_to_current_settlement(self):
        events = [{"ts": 100, "rate": 0.001}, {"ts": 200, "rate": -0.002}]
        times = [100, 200]
        self.assertEqual(funding_at(events, times, 200), 0.001)
        self.assertEqual(funding_at(events, times, 201), -0.002)
        self.assertEqual(funding_at(events, times, 99), 0.0)

    def test_hourly_trend_uses_only_fully_closed_bars(self):
        hour_ms = 60 * 60 * 1000
        hours = [{"ts": i * hour_ms, "close": 100.0 - i, "open": 100.0 - i,
                  "high": 101.0 - i, "low": 99.0 - i, "vol": 1.0}
                 for i in range(30)]
        times = [row["ts"] for row in hours]
        # At 20:00, the 19:00 candle is the latest fully closed one; 20:00 is not yet known.
        self.assertIn("BEARISH", hourly_trend_at(hours, times, 20 * hour_ms))

    def test_wilson_interval_is_not_a_point_claim(self):
        self.assertIsNone(wilson_interval(0, 0))
        low, high = wilson_interval(50, 100)
        self.assertLess(low, 0.5)
        self.assertGreater(high, 0.5)


if __name__ == "__main__":
    unittest.main()
