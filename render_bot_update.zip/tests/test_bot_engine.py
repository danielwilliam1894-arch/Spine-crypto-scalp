import json
import os
import tempfile
import time
import unittest
from unittest.mock import patch
from datetime import datetime, timedelta, timezone
from pathlib import Path

from bot_engine import CryptoScalpBot, LAGOS_TZ


class CryptoScalpBotTests(unittest.TestCase):
    def setUp(self):
        self.tempdir = tempfile.TemporaryDirectory()
        self.state_path = str(Path(self.tempdir.name) / "state.json")
        self.bot = self.make_bot()

    def tearDown(self):
        self.tempdir.cleanup()

    def make_bot(self, balance=1000.0):
        # Keep the test suite incapable of talking to an exchange even if a local .env is armed.
        safe_demo_env = {
            "OKX_DEMO_TRADING": "0", "OKX_DEMO_API_KEY": "",
            "OKX_DEMO_API_SECRET": "", "OKX_DEMO_PASSPHRASE": "",
            "OKX_DEMO_ORDER_ARMED": "0",
        }
        with patch.dict(os.environ, safe_demo_env):
            bot = CryptoScalpBot(initial_balance=balance, state_path=self.state_path)
        bot.enable_telegram = False
        bot.enable_discord = False
        return bot

    @staticmethod
    def long_setup(rsi=50.0):
        return {
            "current_close": 100.0,
            "current_high": 100.4,
            "current_low": 99.8,
            "recent_high": 103.0,
            "recent_low": 98.0,
            "vwap": 101.0,
            "vwap_upper": 101.5,
            "vwap_lower": 100.5,
            "ema8": 102.0,
            "ema20": 101.0,
            "ema50": 99.0,
            "rsi": rsi,
            "atr14": 0.5,
            "latest_range": 0.6,
            "adx": 25.0,
        }

    def set_day(self, bot, now):
        bot.daily_date = now.astimezone(LAGOS_TZ).date().isoformat()
        bot.daily_start_equity = bot.balance
        bot.daily_loss_pause = False
        bot.daily_pause_reason = ""
        bot.consecutive_losses = 0

    def test_original_pillars_use_trigger_vwap_and_rsi_checks(self):
        components = self.bot._confluence_components(self.long_setup())
        self.assertEqual(len(components["LONG"]), 2)
        self.assertIn("Pillar 1 — bullish EMA-ribbon pullback", components["LONG"])
        self.assertIn("Pillar 2 — price at/below lower VWAP band", components["LONG"])
        self.assertEqual(components["SHORT"], [])

        full = self.bot._confluence_components(self.long_setup(rsi=30.0))
        self.assertEqual(len(full["LONG"]), 3)
        self.assertIn("Pillar 3 — RSI momentum low", full["LONG"][-1])
        self.assertEqual(sum(item.startswith("Pillar 1") for item in full["LONG"]), 1)

        # Even when sweep and EMA trigger conditions overlap, pillar one counts once.
        overlap = self.long_setup(rsi=30.0)
        overlap["current_low"] = 97.0
        both_triggers = self.bot._confluence_components(overlap)["LONG"]
        self.assertEqual(sum(item.startswith("Pillar 1") for item in both_triggers), 1)
        self.assertIn("Pillar 1 — liquidity-sweep rejection", both_triggers)

    def test_three_of_three_is_required_in_regular_and_asian_sessions(self):
        symbol = "BTC-USDT-SWAP"
        self.bot.multi_1h_trend[symbol] = "NEUTRAL"
        self.bot.multi_funding[symbol] = 0.0
        regular = datetime(2026, 10, 1, 12, 0, tzinfo=timezone.utc)
        asian = datetime(2026, 10, 1, 23, 0, tzinfo=timezone.utc)
        self.set_day(self.bot, regular)
        self.assertEqual(self.bot._required_confluence(regular), (3, False))
        self.bot.min_confluence_score = 2  # internal override cannot weaken the chosen rule
        self.assertEqual(self.bot._required_confluence(regular), (3, False))
        self.bot.min_confluence_score = 3
        self.assertIsNone(self.bot.evaluate_strategy_signals(self.long_setup(), symbol, now=regular))
        regular_full = self.bot.evaluate_strategy_signals(self.long_setup(rsi=30.0), symbol, now=regular)
        self.assertIsNotNone(regular_full)
        self.assertEqual(regular_full["confluence_score"], 3)
        self.assertEqual(regular_full["session_status"], "Regular session (3/3 required)")

        self.set_day(self.bot, asian)
        self.assertEqual(self.bot._required_confluence(asian), (3, True))
        self.assertIsNone(self.bot.evaluate_strategy_signals(self.long_setup(), symbol, now=asian))
        asian_full = self.bot.evaluate_strategy_signals(self.long_setup(rsi=30.0), symbol, now=asian)
        self.assertIsNotNone(asian_full)
        self.assertEqual(asian_full["confluence_score"], 3)
        self.assertEqual(asian_full["session_status"], "Asian session (3/3 required)")

    def test_adx_is_informational_and_not_a_global_entry_gate(self):
        now = datetime(2026, 10, 1, 12, 0, tzinfo=timezone.utc)
        self.set_day(self.bot, now)
        self.bot.multi_funding["BTC-USDT-SWAP"] = 0.0
        ind = self.long_setup(rsi=30.0)
        ind["adx"] = None
        signal = self.bot.evaluate_strategy_signals(ind, now=now)
        self.assertIsNotNone(signal)
        self.assertIsNone(signal["adx"])

    def test_direct_execution_cannot_bypass_three_of_three_threshold(self):
        now = datetime(2026, 10, 1, 12, 0, tzinfo=timezone.utc)
        self.set_day(self.bot, now)
        signal = {
            "symbol": "BTC-USDT-SWAP", "side": "LONG", "confluence_score": 2,
            "confirmations": ["Pillar 1", "Pillar 2"],
            "entry": 100.0, "sl": 99.0, "tp1": 101.0, "tp2": 103.0,
        }
        with patch.object(self.bot, "_required_confluence", return_value=(3, False)):
            ok, message = self.bot.execute_trade_signal(signal, signal["symbol"])
        self.assertFalse(ok)
        self.assertIn("requires at least 3/3", message)
        self.assertIsNone(self.bot.open_position)

    def test_status_exposes_three_pillar_summary_not_four_vote_data(self):
        symbol = "BTC-USDT-SWAP"
        self.bot.multi_indicators[symbol] = self.long_setup(rsi=30.0)
        status = self.bot.get_status()
        self.assertEqual(status["min_confluence_score"], 3)
        self.assertEqual(status["required_confluence"], 3)
        self.assertEqual(status["current_confluence_summary"]["direction"], "LONG")
        self.assertEqual(status["current_confluence_summary"]["confluence_score"], 3)
        self.assertNotIn("strategy_vote_summary", status)

    def test_two_consecutive_losses_pause_until_next_lagos_day_and_persist(self):
        day1 = datetime(2026, 10, 1, 12, 0, tzinfo=LAGOS_TZ)
        self.set_day(self.bot, day1)
        self.bot._record_trade_outcome(-1.0, now=day1)
        self.assertFalse(self.bot.daily_loss_pause)
        self.bot._record_trade_outcome(-1.0, now=day1)
        self.assertTrue(self.bot.daily_loss_pause)
        self.assertEqual(self.bot.consecutive_losses, 2)

        # Guard state survives process restart within the same local day.
        reloaded = self.make_bot()
        self.assertTrue(reloaded.daily_loss_pause)
        self.assertEqual(reloaded.consecutive_losses, 2)

        day2 = datetime(2026, 10, 2, 0, 1, tzinfo=LAGOS_TZ)
        self.assertTrue(self.bot._refresh_daily_guard(now=day2))
        self.assertFalse(self.bot.daily_loss_pause)
        self.assertEqual(self.bot.consecutive_losses, 0)
        self.assertEqual(self.bot.daily_date, "2026-10-02")

    def test_daily_drawdown_threshold_pauses_entries(self):
        now = datetime(2026, 10, 1, 12, 0, tzinfo=LAGOS_TZ)
        self.set_day(self.bot, now)
        self.bot.balance = 980.0
        self.assertFalse(self.bot._refresh_daily_guard(now=now))
        self.assertTrue(self.bot.daily_loss_pause)
        self.assertAlmostEqual(self.bot.current_daily_drawdown_pct, 2.0)

    def test_real_wilder_adx_distinguishes_trend_from_chop(self):
        rising = []
        for i in range(40):
            close = 100.0 + i
            rising.append({"high": close + 0.5, "low": close - 0.5, "close": close, "vol": 1.0})
        alternating = []
        for i in range(40):
            close = 100.0 + (0.1 if i % 2 else 0.0)
            alternating.append({"high": close + 0.5, "low": close - 0.5, "close": close, "vol": 1.0})
        self.assertGreater(CryptoScalpBot.calculate_adx(rising), 20.0)
        self.assertLess(CryptoScalpBot.calculate_adx(alternating), 20.0)
        self.assertIsNone(CryptoScalpBot.calculate_adx(rising[:20]))

    def test_partial_exit_books_all_fees_and_trade_net_matches_balance(self):
        signal = {
            "symbol": "BTC-USDT-SWAP", "side": "LONG", "confluence_score": 3,
            "entry": 100.0, "sl": 99.0, "tp1": 101.0, "tp2": 103.0,
            "confirmations": ["Pillar 1", "Pillar 2", "Pillar 3"], "reason": "3/3",
        }
        ok, _ = self.bot.execute_trade_signal(signal, signal["symbol"])
        self.assertTrue(ok)
        self.assertLess(self.bot.balance, 1000.0)  # entry taker fee booked
        pos = self.bot.open_position
        self.bot.update_open_position(101.0)
        self.assertTrue(self.bot.open_position["tp1_hit"])
        self.assertGreater(self.bot.balance, 1000.0)
        breakeven_fee_stop = self.bot.open_position["sl_price"]
        self.bot.update_open_position(breakeven_fee_stop)

        self.assertIsNone(self.bot.open_position)
        trade = self.bot.closed_trades[-1]
        self.assertAlmostEqual(trade["net_pnl"], self.bot.balance - 1000.0, places=2)
        self.assertGreater(trade["fees"], 0.0)
        self.assertTrue(trade["win"])

    def test_stale_trade_uses_elapsed_time_not_poll_count(self):
        signal = {
            "symbol": "BTC-USDT-SWAP", "side": "LONG", "confluence_score": 3,
            "entry": 100.0, "sl": 99.0, "tp1": 105.0, "tp2": 110.0,
            "confirmations": ["Pillar 1", "Pillar 2", "Pillar 3"], "reason": "3/3",
        }
        self.bot.execute_trade_signal(signal, signal["symbol"])
        opened = self.bot.open_position["opened_at_epoch"]
        self.bot.update_open_position(100.0, now_ts=opened + self.bot.stale_trade_seconds + 1)
        self.assertIsNone(self.bot.open_position)
        self.assertEqual(self.bot.closed_trades[-1]["close_reason"], "STALE TIME EXIT")

    def test_demo_close_uses_only_the_reduce_only_demo_exit_path(self):
        self.bot.execution_mode = "okx_demo"
        self.bot.okx_demo_client = object()
        self.bot.demo_ready = True
        self.bot._demo_equity_updated = time.time()
        self.bot._demo_instrument = {"lotSz": "0.01", "minSz": "0.01"}
        self.bot.open_position = {
            "execution_mode": "okx_demo", "side": "LONG", "current_price": 100.0,
            "entry_price": 99.0,
        }
        with patch.object(self.bot, "_ensure_demo_ready", return_value=True), \
             patch.object(self.bot, "_demo_exit_position", return_value=True) as demo_exit, \
             patch.object(self.bot, "update_open_position") as paper_update:
            ok, message = self.bot.close_position_market()
        self.assertTrue(ok)
        self.assertIn("OKX demo reduce-only", message)
        demo_exit.assert_called_once_with("MANUAL DEMO CLOSE", full_close=True, current_price=100.0)
        paper_update.assert_not_called()

    def test_unresolved_demo_close_intent_is_not_retried(self):
        self.bot.execution_mode = "okx_demo"
        self.bot.okx_demo_client = object()
        self.bot.open_position = {
            "execution_mode": "okx_demo", "pending_exit_intent": {"client_order_id": "pending"},
            "current_price": 100.0, "entry_price": 99.0,
        }
        with patch.object(self.bot, "_demo_exit_position") as demo_exit:
            ok, message = self.bot.close_position_market()
        self.assertFalse(ok)
        self.assertIn("unresolved", message.lower())
        demo_exit.assert_not_called()

    def test_paper_reset_cannot_erase_open_position_or_reset_demo_ledger(self):
        self.bot.open_position = {"execution_mode": "paper", "id": 1}
        with self.assertRaisesRegex(ValueError, "position is open"):
            self.bot.reset_account(2000)
        self.assertIsNotNone(self.bot.open_position)
        self.bot.open_position = None
        self.bot.execution_mode = "okx_demo"
        with self.assertRaisesRegex(ValueError, "OKX demo mode"):
            self.bot.reset_account(2000)

    def test_status_never_returns_credentials_and_state_file_has_no_secrets(self):
        self.bot.telegram_token = "unit-test-telegram-secret"
        self.bot.telegram_chat_id = "unit-test-chat"
        status = self.bot.get_status()
        for field in ("telegram_token", "telegram_chat_id", "bybit_api_key", "bybit_api_secret", "discord_webhook_url", "bybit_credentials_configured"):
            self.assertNotIn(field, status)
        self.assertTrue(status["telegram_configured"])
        self.assertFalse(hasattr(self.bot, "bybit_api_key"))
        self.assertFalse(hasattr(self.bot, "bybit_api_secret"))
        self.assertFalse(hasattr(self.bot, "bybit_place_order"))
        self.bot._save_state()
        saved = Path(self.state_path).read_text(encoding="utf-8")
        self.assertNotIn("unit-test-telegram-secret", saved)

    def test_exchange_credentials_are_ignored_by_paper_build(self):
        with patch.dict(os.environ, {"BYBIT_API_KEY": "test-key", "BYBIT_API_SECRET": "test-secret"}):
            fresh_bot = CryptoScalpBot(initial_balance=1000.0, state_path=self.state_path)
        self.assertFalse(hasattr(fresh_bot, "bybit_api_key"))
        self.assertFalse(hasattr(fresh_bot, "bybit_api_secret"))
        self.assertFalse(hasattr(fresh_bot, "bybit_place_order"))
        self.assertNotIn("bybit_credentials_configured", fresh_bot.get_status())

    def test_live_mode_and_manual_orders_are_blocked(self):
        self.bot.execution_mode = "bybit"
        signal = {
            "symbol": "BTC-USDT-SWAP", "side": "LONG", "confluence_score": 3,
            "entry": 100.0, "sl": 99.0, "tp1": 101.0, "tp2": 103.0,
            "confirmations": ["1", "2", "3"],
        }
        ok, message = self.bot.execute_trade_signal(signal, signal["symbol"])
        self.assertFalse(ok)
        self.assertIn("no order was sent", message.lower())
        self.assertIsNone(self.bot.open_position)
        manual_ok, _ = self.bot.manual_trigger("LONG")
        self.assertFalse(manual_ok)


if __name__ == "__main__":
    unittest.main()
