# Render deployment guide — BTC Telegram signal scanner

This deploy runs the original three-pillar BTC scanner and sends Telegram **setup alerts**. Entries require 3/3 pillars in every session; 2/3 is watch-only. Alerts are not trade instructions or order confirmations. The active code does not support live exchange orders; execution is paper by default, with OKX demo-only safeguards in the code.

## 1. Deploy the current code to the GitHub repository linked to Render

The files in this workspace are not automatically copied to GitHub or Render. Commit/upload the current project files to the branch Render deploys. At minimum, include:

- `app.py`
- `bot_engine.py`
- `okx_demo.py`
- `render_wsgi.py`
- `Procfile`
- `requirements.txt`
- `Dockerfile` (only needed if the Render service uses Docker)

Do not upload `.env`, tokens, exchange keys, `bot_state.json`, or other secrets. The repository `.gitignore` excludes `.env` and the state file.

## 2. Configure the Render web service

For a native Python service:

- Build command: `pip install -r requirements.txt`
- Start command: `gunicorn --workers 1 --threads 8 --timeout 120 --bind 0.0.0.0:$PORT render_wsgi:app`

The `Procfile` already contains this start command. One Gunicorn worker is intentional: the scanner and Telegram poller run inside the web process, and multiple workers would create duplicate scanners/pollers. If the service is configured to use Docker, deploy the included Dockerfile instead.

## 3. Add Telegram credentials in Render (not GitHub)

In the service's **Environment** settings, add `TELEGRAM_BOT_TOKEN` with the fresh token from BotFather. Save and wait for deployment to finish. Do not paste the token into chat, source code, or a screenshot.

With only the token set, open a private chat with the new bot and send `/start`. The bot replies with your numeric chat ID. Add that as `TELEGRAM_CHAT_ID` in Render Environment settings, save, and wait for the service to restart. Then send `/test` to the bot to verify delivery; the test does not place an order.

After startup, Render logs should include `Telegram command listener started`. `Unauthorized` indicates a bad/revoked token. A `409 Conflict` indicates another poller or a webhook is active for that bot.

## 4. Keep the scanner online

Render Free web services can spin down after inactivity. A sleeping service cannot scan continuously or poll Telegram. Unattended alerts require an always-on service/host. The Free service can still be used for a temporary connectivity test, but it is not a reliable 24/7 scanner.

## 5. Verify behavior

1. Confirm Render shows the latest GitHub commit as deployed and the service is Live.
2. Confirm the Telegram `/test` message arrives.
3. Wait for a qualifying closed 5-minute BTC setup. Only a confirmed 3/3 setup triggers a strategy alert; there may be no qualifying setup for a while.

A successful deploy or test alert verifies connectivity, not strategy profitability. Keep all credentials private and do not enable real-money order execution.
