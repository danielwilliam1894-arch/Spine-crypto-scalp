# OKX BTC-USDT-SWAP Three-Pillar Strategy Bot

The active scanner has been restored to the original three-pillar setup logic. This is an implementation change—not evidence that the strategy is profitable or validated for live trading. The only configured instrument is OKX `BTC-USDT-SWAP`. Exchange execution is restricted to OKX Demo Trading; there is no live endpoint or live-key fallback. Without demo credentials the app uses paper simulation.

## Active signal rules

Signals use completed 5-minute candles and the following three directional pillars:

1. **Setup trigger:** either a liquidity-sweep rejection or an EMA-ribbon pullback/rally. Either trigger counts as one pillar, never two.
2. **VWAP-band location:** price is at/below the lower rolling VWAP band for a long, or at/above the upper band for a short.
3. **RSI momentum:** RSI-14 below 42 supports a long; RSI-14 above 58 supports a short.

The entry threshold is now **3 of 3 in every session**, including regular hours and the Asian UTC window (22:00–06:00). A 2/3 reading is watch-only and cannot open a position. ADX is displayed as market context but is not an entry gate. The scanner evaluates only confirmed 5-minute candles and only one position may be open at a time.

The original 1-hour trend alignment, funding shield, volatility circuit breaker and daily risk guards remain active. A bearish 1-hour trend can block longs and a bullish one can block shorts; crowded funding can block same-direction entries. The volatility stop/cooldown, 2% daily drawdown pause, and two-consecutive-loss pause also remain in place.

## Risk and execution safety

- Default planned stop risk: **1% of current equity**, including estimated fees and slippage reserves.
- Maximum leverage: **10×**; maximum initial margin: **$3**. OKX contract quantity is rounded down using runtime instrument increments.
- Existing ATR stop/target and 50% TP1 scale-out management are retained. Gaps, fees, slippage, outages, and exchange behavior can make actual losses differ from the plan.
- Manual entry is disabled. Demo orders require server-side OKX demo credentials and `OKX_DEMO_ORDER_ARMED=1`. Leave the arm off until the demo lifecycle has been reviewed. The bot must never be pointed at live keys.
- A Telegram setup alert is a signal notification, not an order confirmation. Alerts can be sent even when a later safety/sizing check blocks entry.

## Performance and testing

The strategy is **unproven, not guaranteed profitable**. Existing `backtest_results/` are from an older multi-pair research replay; they do not establish performance for this BTC-only runtime configuration. Do not treat historical win rates as forecasts. A proper assessment requires a reproducible BTC-only replay with fees/slippage, a chronological out-of-sample holdout that is not used for tuning, and forward paper tracking. No profitability claim is made here.

Run the unit tests and local development app with:

```bash
python3 -m pip install -r requirements.txt
python3 -m unittest discover -s tests -v
python3 app.py
```

## Render deployment

The `Procfile` uses Gunicorn with one worker. One worker is intentional: the scanner and Telegram long-poll listener run in the web process and must not be duplicated. Render build command: `pip install -r requirements.txt`. Render start command: use the Procfile, or set `gunicorn --workers 1 --threads 8 --timeout 120 --bind 0.0.0.0:$PORT render_wsgi:app`.

Set `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` in Render's Environment settings, not in GitHub or source files. After deployment, check logs for `Telegram command listener started`, then send `/test` to the bot. Render Free instances sleep when idle and cannot guarantee continuous scanning; use an always-on service for unattended alerts. A Telegram signal alert is informational and does not place a real exchange order.

## Telegram setup

Telegram credentials are loaded from the server environment or a private project-root `.env` file. They are not accepted by dashboard fields, returned by the API, or saved in the bot state. Never paste a bot token into chat, the dashboard, or source code. If a token was exposed, revoke it with BotFather and use a new one.

```dotenv
TELEGRAM_BOT_TOKEN=your_new_token_from_BotFather
TELEGRAM_CHAT_ID=your_numeric_private_or_group_chat_id
```

With only `TELEGRAM_BOT_TOKEN` set, start the scanner and send `/start` (or `/id`) to the bot. It will reply with the numeric chat ID in setup-only mode. Add that value as `TELEGRAM_CHAT_ID`, then restart. Until the chat ID is configured, other bot commands remain blocked. For groups, add the bot and use `/start@BotUsername` to obtain the group ID.

The dashboard's **Send Test Alert** control and Telegram `/test` command send a connectivity-only message and place no order. The command listener runs only while the scanner is started; an active Telegram webhook conflicts with `getUpdates` polling. Markdown delivery falls back to plain text if Telegram rejects its formatting.

## Dashboard and workspace status

The dashboard is read-only unless `DASHBOARD_PASSWORD` is set; when set, authenticate as `admin`. Never enter exchange or Telegram secrets in the browser. Paper-ledger reset is disabled while a position is open and in OKX demo mode. A demo close uses the reduce-only demo route, not paper accounting.

No Telegram token/chat ID or OKX demo credentials are present in this workspace. **No real Telegram message, OKX demo order, or live order has been sent.** Set Telegram credentials privately and use the test-alert button to verify delivery; do not send credentials in chat.
